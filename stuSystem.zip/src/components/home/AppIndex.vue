<template>
    <div id="appindex">
    </div>
</template>
<script>

export default {
    name: 'Appindex',
    components: {
    }
}
</script>
<style></style>